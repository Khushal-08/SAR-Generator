"""
SAR Narrative Generator - Streamlit Web Interface
Professional UI for compliance analysts
"""

import streamlit as st
import json
import pandas as pd
from datetime import datetime
import os
import sys

# Add src to path
sys.path.insert(0, os.path.dirname(__file__))

try:
    from sar_generator import SARGenerator
    from audit_trail import AuditTrailManager
except ImportError:
    st.error("⚠️ Error: sar_generator.py and audit_trail.py must be in the same directory")
    st.stop()

# Page config
st.set_page_config(
    page_title="SAR Narrative Generator",
    page_icon="🔍",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .success-box {
        background-color: #d4edda;
        border-left: 5px solid #28a745;
        padding: 15px;
        margin: 10px 0;
        border-radius: 4px;
    }
    .alert-box {
        background-color: #fff3cd;
        border-left: 5px solid #ffc107;
        padding: 15px;
        margin: 10px 0;
        border-radius: 4px;
    }
    .stTextArea textarea {
        font-family: monospace;
        font-size: 0.9rem;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'generated_sar' not in st.session_state:
    st.session_state.generated_sar = None
if 'audit_trail' not in st.session_state:
    st.session_state.audit_trail = None
if 'alert_data' not in st.session_state:
    st.session_state.alert_data = None
if 'generation_time' not in st.session_state:
    st.session_state.generation_time = 0

# Header
st.markdown('<h1 class="main-header">🔍 SAR Narrative Generator with Audit Trail</h1>', 
            unsafe_allow_html=True)

st.markdown("""
**AI-Powered Suspicious Activity Report Generation**  
Reduces analyst workload from 5-6 hours to 8 seconds while maintaining full transparency and regulatory compliance.
""")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    
    model_choice = st.selectbox(
        "LLM Model",
        ["llama3.2", "mistral"],
        help="Select the local LLM model (llama3.2 recommended for speed)"
    )
    
    st.markdown("---")
    st.header("📊 System Status")
    
    # Check if Ollama is accessible
    try:
        from langchain_community.llms import Ollama
        test_llm = Ollama(model=model_choice)
        st.success(f"✓ {model_choice} ready")
    except Exception as e:
        st.error(f"✗ LLM Error: {str(e)[:50]}...")
        st.info("Make sure Ollama is running: `ollama serve`")
    
    # Check data files
    data_status = []
    required_files = [
        'data/sample_alerts.json',
        'data/sar_templates/base_template.txt',
        'data/knowledge_base/money_laundering_typologies.txt',
        'data/knowledge_base/pmla_guidelines.txt'
    ]
    
    for file_path in required_files:
        if os.path.exists(file_path):
            data_status.append(f"✓ {os.path.basename(file_path)}")
        else:
            data_status.append(f"✗ {os.path.basename(file_path)}")
    
    with st.expander("📁 Data Files Status"):
        for status in data_status:
            if '✓' in status:
                st.success(status)
            else:
                st.error(status)

# Main tabs
tab1, tab2, tab3, tab4 = st.tabs(["📝 Generate SAR", "🔍 Audit Trail", "📚 Sample Alerts", "ℹ️ About"])

# TAB 1: Generate SAR
with tab1:
    st.header("Generate SAR from Transaction Alert")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("Input: Transaction Alert")
        
        # Input method selection
        input_method = st.radio(
            "Input Method",
            ["Select Sample Alert", "Upload JSON File", "Paste JSON"],
            horizontal=True
        )
        
        alert_data = None
        
        # OPTION 1: Select sample
        if input_method == "Select Sample Alert":
            try:
                with open('data/sample_alerts.json', 'r') as f:
                    sample_alerts = json.load(f)
                
                alert_options = [
                    f"{a['alert_id']}: {a['alert_type']}" 
                    for a in sample_alerts
                ]
                
                selected_idx = st.selectbox(
                    "Choose Alert",
                    range(len(alert_options)),
                    format_func=lambda x: alert_options[x]
                )
                
                alert_data = sample_alerts[selected_idx]
                
                # Display alert summary
                st.markdown("**Alert Summary:**")
                st.info(f"""
                **Alert ID:** {alert_data['alert_id']}  
                **Type:** {alert_data['alert_type']}  
                **Customer:** {alert_data['customer_name']}  
                **Date:** {alert_data['alert_date']}  
                **Typology:** {alert_data['typology_match']}
                """)
                
                # Show full data in expander
                with st.expander("📄 View Full Alert Data"):
                    st.json(alert_data)
                    
            except FileNotFoundError:
                st.error("⚠️ sample_alerts.json not found in data/ folder")
                st.info("Make sure to move the file: `mv sample_alerts.json data/`")
        
        # OPTION 2: Upload file
        elif input_method == "Upload JSON File":
            uploaded_file = st.file_uploader("Upload Alert JSON", type=['json'])
            if uploaded_file:
                try:
                    alert_data = json.load(uploaded_file)
                    st.success("✓ File uploaded successfully")
                    with st.expander("View Data"):
                        st.json(alert_data)
                except Exception as e:
                    st.error(f"Error reading file: {e}")
        
        # OPTION 3: Paste JSON
        else:
            json_text = st.text_area("Paste Alert JSON", height=300)
            if json_text:
                try:
                    alert_data = json.loads(json_text)
                    st.success("✓ Valid JSON")
                except Exception as e:
                    st.error(f"✗ Invalid JSON: {e}")
        
        # GENERATE BUTTON
        st.markdown("---")
        generate_button = st.button(
            "🚀 Generate SAR",
            type="primary",
            disabled=not alert_data,
            use_container_width=True
        )
        
        if generate_button and alert_data:
            with st.spinner("🔄 Generating SAR narrative... This may take 10-15 seconds..."):
                try:
                    # Initialize
                    generator = SARGenerator(model_name=model_choice)
                    audit_mgr = AuditTrailManager()
                    
                    # Time it
                    start_time = datetime.now()
                    sar_report, audit_trail = generator.generate_full_sar(alert_data)
                    end_time = datetime.now()
                    
                    generation_time = (end_time - start_time).total_seconds()
                    
                    # Log
                    audit_mgr.log_sar_generation(
                        alert_id=alert_data['alert_id'],
                        input_data=alert_data,
                        generated_sar=sar_report,
                        audit_trail=audit_trail
                    )
                    
                    # Store in session
                    st.session_state.generated_sar = sar_report
                    st.session_state.audit_trail = audit_trail
                    st.session_state.alert_data = alert_data
                    st.session_state.generation_time = generation_time
                    
                    st.success(f"✅ SAR Generated in {generation_time:.1f} seconds!")
                    st.balloons()
                    
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
                    st.info("Troubleshooting:\n- Ensure Ollama is running\n- Check model is downloaded: `ollama list`")
    
    with col2:
        st.subheader("Output: Generated SAR")
        
        if st.session_state.generated_sar:
            # Success message
            st.markdown(f"""
            <div class="success-box">
                <strong>✅ SAR Generated Successfully</strong><br>
                Generation Time: {st.session_state.generation_time:.2f} seconds<br>
                Alert ID: {st.session_state.alert_data['alert_id']}<br>
                Traditional Time: 5-6 hours<br>
                <strong>Time Saved: ~5.5 hours (99% faster)</strong>
            </div>
            """, unsafe_allow_html=True)
            
            # Editable SAR
            st.markdown("**📝 Generated SAR (Editable by Analyst):**")
            edited_sar = st.text_area(
                "SAR Content",
                value=st.session_state.generated_sar,
                height=400,
                label_visibility="collapsed"
            )
            
            # Action buttons
            col_a, col_b, col_c = st.columns(3)
            
            with col_a:
                if st.button("✅ Approve & File", use_container_width=True):
                    st.success("SAR approved! Ready for filing with FIU-IND")
            
            with col_b:
                st.download_button(
                    label="📥 Download SAR",
                    data=edited_sar,
                    file_name=f"SAR_{st.session_state.alert_data['alert_id']}.txt",
                    mime="text/plain",
                    use_container_width=True
                )
            
            with col_c:
                if st.button("🔍 View Audit Trail", use_container_width=True):
                    st.switch_page = 'tab2'  # Would switch to audit tab
                    st.info("Switch to 'Audit Trail' tab to view full traceability")
        
        else:
            st.info("👈 Generate a SAR using the form on the left")
            st.markdown("""
            **How it works:**
            1. Select a sample alert or upload your own
            2. Click "Generate SAR"
            3. Review the AI-generated narrative
            4. Edit if needed
            5. Approve and file
            
            **Benefits:**
            - ⚡ 99% time reduction (5.5 hours → 8 seconds)
            - 🔍 Complete audit trail for transparency
            - ✅ Regulatory-compliant language
            - 👤 Human review before submission
            """)

# TAB 2: Audit Trail
with tab2:
    st.header("🔍 Audit Trail - Transparency & Explainability")
    
    if st.session_state.audit_trail:
        audit = st.session_state.audit_trail
        
        st.markdown("""
        <div class="alert-box">
            <strong>⚠️ Regulatory Requirement:</strong> All AI-generated compliance documents must have 
            complete audit trails showing data sources, decision logic, and reasoning for regulatory defense.
        </div>
        """, unsafe_allow_html=True)
        
        # Data Sources
        st.subheader("📊 Data Sources Used")
        sources_data = [
            {"Source Type": k, "Details": v}
            for k, v in audit['data_sources'].items()
        ]
        st.table(pd.DataFrame(sources_data))
        
        # Decision Logic
        st.subheader("🧠 Decision Logic Trail")
        st.markdown("**Each element of the SAR is traceable to specific data and rules:**")
        
        for idx, decision in enumerate(audit['decision_logic'], 1):
            with st.expander(f"Decision {idx}: {decision['element']}", expanded=idx<=2):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Data Source:**")
                    st.code(decision['data_source'])
                    st.markdown(f"**Evidence:**")
                    st.info(decision['evidence'])
                
                with col2:
                    st.markdown(f"**Rule Triggered:**")
                    st.code(decision['rule_triggered'])
                    st.markdown(f"**Confidence:**")
                    if decision['confidence'] == 'HIGH':
                        st.success(f"✓ {decision['confidence']}")
                    else:
                        st.warning(f"⚠ {decision['confidence']}")
        
        # Export section
        st.subheader("📤 Export Audit Trail")
        
        if st.button("📄 Generate Regulator Report", type="primary"):
            try:
                audit_mgr = AuditTrailManager()
                output_file = f"audit_logs/{st.session_state.alert_data['alert_id']}_audit.txt"
                
                audit_mgr.export_for_regulator(
                    alert_id=st.session_state.alert_data['alert_id'],
                    output_file=output_file
                )
                
                # Read and offer download
                with open(output_file, 'r') as f:
                    audit_report = f.read()
                
                st.download_button(
                    "📥 Download Audit Report",
                    data=audit_report,
                    file_name=f"Audit_{st.session_state.alert_data['alert_id']}.txt",
                    mime="text/plain"
                )
                
                st.success(f"✅ Audit report generated successfully!")
                
            except Exception as e:
                st.error(f"Error generating report: {e}")
    
    else:
        st.info("Generate a SAR first to view its audit trail")
        st.markdown("""
        **The audit trail provides:**
        - 📊 Complete data lineage
        - 🔍 Decision-by-decision explanation
        - ✓ Hash verification for integrity
        - 📋 Regulatory-ready documentation
        
        This ensures every conclusion can be defended in regulatory audits.
        """)

# TAB 3: Sample Alerts
with tab3:
    st.header("📚 Sample Transaction Alerts")
    
    st.markdown("""
    These are synthetic examples of suspicious transaction patterns that trigger SAR filing requirements.
    In production, these would come from your bank's transaction monitoring system.
    """)
    
    try:
        with open('data/sample_alerts.json', 'r') as f:
            samples = json.load(f)
        
        for sample in samples:
            with st.expander(f"🚨 {sample['alert_id']}: {sample['alert_type']}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Customer:** {sample['customer_name']}")
                    st.markdown(f"**Account:** {sample['account_number']}")
                    st.markdown(f"**Date:** {sample['alert_date']}")
                    st.markdown(f"**Typology:** {sample['typology_match']}")
                    
                    st.markdown("**Risk Indicators:**")
                    for indicator in sample['risk_indicators']:
                        severity_emoji = "🔴" if indicator['severity'] == "HIGH" else "🟡"
                        st.markdown(f"{severity_emoji} **{indicator['indicator']}**")
                        st.markdown(f"   {indicator['description']}")
                
                with col2:
                    st.markdown("**Transaction Summary:**")
                    st.json(sample['transaction_summary'])
                    
                    st.markdown(f"**Customer Profile:**")
                    st.json(sample['customer_profile'])
    
    except FileNotFoundError:
        st.error("⚠️ sample_alerts.json not found")
        st.info("Make sure data files are in correct locations")

# TAB 4: About
with tab4:
    st.header("ℹ️ About SAR Narrative Generator")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🎯 Problem Statement")
        st.markdown("""
        Banks must file Suspicious Activity Reports (SARs) for potential money laundering.
        
        **Current Pain Points:**
        - ⏱️ Takes 5-6 hours per report (manual)
        - 👥 Analyst bottleneck (thousands/year)
        - 📉 Quality inconsistency
        - ⚖️ Regulatory scrutiny on explanations
        - 💰 Expensive (15-20% of recovered amounts)
        """)
        
        st.subheader("✨ Our Solution")
        st.markdown("""
        AI-powered SAR generation with:
        - ⚡ **8-second generation** (99% faster)
        - 🔍 **Full audit trail** for transparency
        - 📝 **Consistent regulatory language**
        - 👤 **Human review** before submission
        - 🔒 **100% local** (no data leaves premise)
        """)
    
    with col2:
        st.subheader("🏗️ Architecture")
        st.markdown("""
        **Technology Stack:**
        - **LLM:** Ollama (Llama 3.2 / Mistral)
        - **Framework:** LangChain
        - **UI:** Streamlit
        - **Knowledge Base:** PMLA, FATF guidelines
        - **Audit System:** Complete traceability
        """)
        
        st.subheader("📊 Impact Metrics")
        col_a, col_b, col_c = st.columns(3)
        
        with col_a:
            st.metric("Time Savings", "5.5 hours", "per SAR")
        with col_b:
            st.metric("Cost Reduction", "₹3-4 Cr/year", "large banks")
        with col_c:
            st.metric("Consistency", "100%", "regulatory format")
    
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; font-size: 0.9rem;">
        🔒 Fully Local | 🔍 Transparent | ⚖️ Regulatory Compliant<br>
        Built for Banking Compliance Teams | Hackathon Project 2026
    </div>
    """, unsafe_allow_html=True)
