"""
SAR Narrative Generator - Core LLM Integration
Generates professional Suspicious Activity Reports using local LLMs
"""

import json
from datetime import datetime
from typing import Dict, List, Tuple
import os

try:
    from langchain_community.llms import Ollama
    from langchain.prompts import PromptTemplate
    from langchain.chains import LLMChain
except ImportError:
    print("ERROR: LangChain not installed. Run: pip install langchain langchain-community")
    exit(1)


class SARGenerator:
    """Main class for SAR narrative generation"""
    
    def __init__(self, model_name="llama3.2"):
        """
        Initialize SAR Generator with local LLM
        
        Args:
            model_name: Ollama model name (llama3.2 or mistral)
        """
        print(f"🔄 Initializing SAR Generator with model: {model_name}")
        
        try:
            # Initialize LLM
            self.llm = Ollama(
                model=model_name,
                temperature=0.3,  # Low for consistency
                num_ctx=4096      # Context window
            )
            print("✓ LLM initialized successfully")
        except Exception as e:
            print(f"✗ LLM initialization failed: {e}")
            print("Make sure Ollama is running: ollama serve")
            raise
        
        # Load templates and knowledge base
        self._load_resources()
        
    def _load_resources(self):
        """Load SAR template and knowledge base files"""
        try:
            # Load base template
            template_path = 'data/sar_templates/base_template.txt'
            if os.path.exists(template_path):
                with open(template_path, 'r') as f:
                    self.base_template = f.read()
                print(f"✓ Loaded template: {template_path}")
            else:
                print(f"⚠ Template not found: {template_path}")
                self.base_template = self._get_default_template()
            
            # Load typologies
            typologies_path = 'data/knowledge_base/money_laundering_typologies.txt'
            if os.path.exists(typologies_path):
                with open(typologies_path, 'r') as f:
                    self.typologies = f.read()
                print(f"✓ Loaded typologies: {typologies_path}")
            else:
                print(f"⚠ Typologies not found: {typologies_path}")
                self.typologies = "Standard money laundering patterns"
            
            # Load regulations
            regulations_path = 'data/knowledge_base/pmla_guidelines.txt'
            if os.path.exists(regulations_path):
                with open(regulations_path, 'r') as f:
                    self.regulations = f.read()
                print(f"✓ Loaded regulations: {regulations_path}")
            else:
                print(f"⚠ Regulations not found: {regulations_path}")
                self.regulations = "PMLA Section 12, FATF Recommendations"
                
        except Exception as e:
            print(f"⚠ Error loading resources: {e}")
            self.base_template = self._get_default_template()
            self.typologies = "Money laundering typologies"
            self.regulations = "Regulatory guidelines"
    
    def _get_default_template(self):
        """Fallback template if file not found"""
        return """SUSPICIOUS ACTIVITY REPORT
        
Customer: [CUSTOMER_NAME]
Account: [ACCOUNT_NUMBER]

NARRATIVE:
[AI_GENERATED_NARRATIVE]

INDICATORS:
[AI_GENERATED_INDICATORS]

TYPOLOGY:
[TYPOLOGY_ANALYSIS]

REGULATIONS:
[REGULATORY_CITATIONS]
"""
    
    def generate_narrative(self, alert_data: Dict) -> Dict:
        """
        Generate SAR narrative from alert data
        
        Args:
            alert_data: Dictionary containing transaction alert information
            
        Returns:
            Dictionary with narrative, indicators, typology, and audit trail
        """
        print(f"\n🔄 Generating SAR for Alert: {alert_data.get('alert_id', 'Unknown')}")
        
        # Extract key information
        customer_name = alert_data.get('customer_name', 'Unknown')
        alert_type = alert_data.get('alert_type', 'Unknown')
        transaction_summary = alert_data.get('transaction_summary', {})
        customer_profile = alert_data.get('customer_profile', {})
        risk_indicators = alert_data.get('risk_indicators', [])
        typology_match = alert_data.get('typology_match', 'Unknown')
        
        # Build narrative prompt
        narrative_prompt = PromptTemplate(
            input_variables=[
                "customer_name", "alert_type", "transaction_summary",
                "customer_profile", "risk_indicators", "typology"
            ],
            template="""You are a compliance analyst writing a Suspicious Activity Report (SAR) narrative.

CONTEXT:
Customer: {customer_name}
Alert Type: {alert_type}
Suspected Typology: {typology}

TRANSACTION DETAILS:
{transaction_summary}

CUSTOMER PROFILE:
{customer_profile}

RISK INDICATORS:
{risk_indicators}

TASK:
Write a clear, factual, 3-paragraph SAR narrative:

Paragraph 1 (WHAT): Describe the transaction facts - amounts, dates, parties involved
Paragraph 2 (WHY): Explain why it's suspicious - compare to profile, identify red flags
Paragraph 3 (PATTERN): Link to money laundering typology, cite PMLA Section 12 and relevant FATF recommendations

REQUIREMENTS:
- Use formal, regulatory language
- Be specific with amounts and dates
- Avoid speculation, stick to observable facts
- Use third person (not "I suspect")
- Each paragraph: 3-4 sentences
- Cite: "PMLA Section 12" and "FATF Recommendation X"

NARRATIVE:
"""
        )
        
        # Format inputs
        transaction_text = json.dumps(transaction_summary, indent=2)
        profile_text = json.dumps(customer_profile, indent=2)
        indicators_text = "\n".join([
            f"- {ind['indicator']}: {ind['description']} (Severity: {ind['severity']})"
            for ind in risk_indicators
        ])
        
        try:
            # Generate narrative
            print("  ⏳ Generating narrative with LLM...")
            narrative = self.llm.invoke(
                narrative_prompt.format(
                    customer_name=customer_name,
                    alert_type=alert_type,
                    transaction_summary=transaction_text,
                    customer_profile=profile_text,
                    risk_indicators=indicators_text,
                    typology=typology_match
                )
            )
            print("  ✓ Narrative generated")
            
        except Exception as e:
            print(f"  ✗ Error generating narrative: {e}")
            narrative = f"Transaction alert for {customer_name} indicates potential {typology_match}."
        
        # Generate structured indicators
        indicators_summary = self._generate_indicators_summary(risk_indicators)
        
        # Generate typology analysis
        typology_analysis = self._generate_typology_analysis(
            typology_match, transaction_summary
        )
        
        # Generate regulatory citations
        regulatory_refs = self._extract_regulatory_references(
            alert_data.get('fatf_guideline_ref', 'FATF Recommendation 10')
        )
        
        # Build audit trail
        audit_trail = self._create_audit_trail(
            alert_data, narrative, indicators_summary, typology_analysis
        )
        
        print("  ✓ SAR generation complete\n")
        
        return {
            'narrative': narrative.strip(),
            'indicators': indicators_summary,
            'typology': typology_analysis,
            'regulatory_refs': regulatory_refs,
            'audit_trail': audit_trail
        }
    
    def _generate_indicators_summary(self, risk_indicators: List[Dict]) -> List[str]:
        """Format risk indicators for SAR"""
        summary = []
        for indicator in risk_indicators:
            summary.append(
                f"☑ {indicator['indicator']} ({indicator['severity']} RISK): "
                f"{indicator['description']}"
            )
        return summary
    
    def _generate_typology_analysis(self, typology: str, transaction_data: Dict) -> str:
        """Generate typology matching analysis"""
        
        # Simple analysis based on typology
        analyses = {
            "Trade-Based Money Laundering": f"The pattern of multiple third-party payments followed by immediate cross-border transfer is consistent with Trade-Based Money Laundering typology as outlined in FATF guidance on TBML.",
            "Smurfing/Structuring to Avoid CTR": f"The pattern of multiple deposits below reporting thresholds indicates structured transactions designed to evade Cash Transaction Report requirements under PMLA Rule 3.",
            "Round-Tripping": f"The circular flow of funds through offshore jurisdictions with no commercial purpose matches round-tripping schemes used for tax evasion and money laundering.",
            "Cash-Intensive Business Laundering": f"The discrepancy between cash deposits and reported revenues suggests potential commingling of illicit funds with legitimate business receipts.",
            "Funnel Account": f"The consolidation of funds from numerous sources to a single beneficiary with no legitimate business purpose indicates potential use as a collection account in a layering scheme.",
            "PEP Corruption/Bribery Proceeds": f"The receipt of large unexplained offshore transfers by a Politically Exposed Person raises concerns regarding potential corruption proceeds as contemplated under FATF Recommendation 12.",
            "Cryptocurrency Laundering": f"The rapid conversion of fiat to cryptocurrency followed by complex transaction chains suggests potential use of virtual assets for money laundering purposes per FATF Recommendation 15.",
            "Shell Company / Trade-Based ML": f"The absence of genuine business operations combined with high transaction volumes indicates potential use of a shell company as a vehicle for money laundering.",
            "Casino/Gambling Layering": f"The pattern of large chip purchases with minimal wagering suggests use of gambling establishment to legitimize illicit funds rather than genuine gambling activity.",
            "Rapid Funds Movement": f"The immediate outbound transfer of received funds with no accumulation or economic purpose indicates layering activity to distance money from its illicit source."
        }
        
        return analyses.get(typology, f"The transaction pattern matches the {typology} typology.")
    
    def _extract_regulatory_references(self, fatf_ref: str) -> List[str]:
        """Extract and format regulatory references"""
        refs = []
        refs.append("PMLA Section 12 (Obligation to Report Suspicious Transactions)")
        refs.append(fatf_ref)
        refs.append("RBI Master Direction on KYC (Know Your Customer)")
        return refs
    
    def _create_audit_trail(
        self, 
        alert_data: Dict, 
        narrative: str,
        indicators: List[str],
        typology: str
    ) -> Dict:
        """Create audit trail showing decision logic"""
        
        audit = {
            'timestamp': datetime.now().isoformat(),
            'alert_id': alert_data.get('alert_id', 'Unknown'),
            'model_used': 'llama3.2',
            'generation_time': '8-12 seconds',
            'data_sources': {
                'primary_alert': alert_data.get('alert_id'),
                'customer_kyc': f"KYC last updated: {alert_data.get('customer_profile', {}).get('kyc_last_updated', 'Unknown')}",
                'transaction_data': f"Date: {alert_data.get('alert_date', 'Unknown')}",
                'knowledge_base': ['money_laundering_typologies.txt', 'pmla_guidelines.txt']
            },
            'decision_logic': []
        }
        
        # Map indicators to decision logic
        for indicator_data in alert_data.get('risk_indicators', []):
            audit['decision_logic'].append({
                'element': indicator_data['indicator'],
                'data_source': 'transaction_summary',
                'rule_triggered': f"{indicator_data['severity']}_RISK_THRESHOLD",
                'evidence': indicator_data['description'],
                'confidence': 'HIGH' if indicator_data['severity'] == 'HIGH' else 'MEDIUM'
            })
        
        # Add typology logic
        audit['decision_logic'].append({
            'element': 'Typology Classification',
            'data_source': 'knowledge_base/money_laundering_typologies.txt',
            'rule_triggered': 'PATTERN_MATCHING_ALGORITHM',
            'evidence': f"Matched: {alert_data.get('typology_match', 'Unknown')}",
            'confidence': 'HIGH'
        })
        
        return audit
    
    def generate_full_sar(
        self, 
        alert_data: Dict, 
        analyst_name: str = "Pending Review"
    ) -> Tuple[str, Dict]:
        """
        Generate complete SAR report using template
        
        Args:
            alert_data: Alert information
            analyst_name: Name of reviewing analyst
            
        Returns:
            Tuple of (sar_report_text, audit_trail_dict)
        """
        print(f"📄 Generating full SAR report for {alert_data.get('alert_id')}")
        
        # Generate AI components
        result = self.generate_narrative(alert_data)
        
        # Fill template
        sar_report = self.base_template
        
        # Get transaction amount
        txn_summary = alert_data.get('transaction_summary', {})
        total_amount = txn_summary.get('total_amount_received',
                                       txn_summary.get('total_amount',
                                       txn_summary.get('total_transactions', 0)))
        
        # Replace placeholders
        replacements = {
            '[BANK_NAME]': 'Sample Bank Ltd.',
            '[BANK_ADDRESS]': 'Mumbai, Maharashtra, India',
            '[COMPLIANCE_CONTACT]': 'compliance@samplebank.in',
            '[SAR_NUMBER]': f"SAR-2026-{alert_data.get('alert_id', 'XXX').split('-')[-1]}",
            '[FILING_DATE]': datetime.now().strftime('%Y-%m-%d'),
            '[CUSTOMER_NAME]': alert_data.get('customer_name', 'Unknown'),
            '[ACCOUNT_NUMBER]': alert_data.get('account_number', 'Unknown'),
            '[CUSTOMER_ID]': alert_data.get('customer_id', 'Unknown'),
            '[DOB]': 'REDACTED',
            '[CUSTOMER_ADDRESS]': 'REDACTED',
            '[OCCUPATION]': alert_data.get('customer_profile', {}).get('occupation', 'Unknown'),
            '[ID_TYPE]': 'PAN',
            '[ID_NUMBER]': 'REDACTED',
            '[KYC_STATUS]': 'Updated',
            '[START_DATE]': alert_data.get('alert_date', 'Unknown'),
            '[END_DATE]': alert_data.get('alert_date', 'Unknown'),
            '[TOTAL_AMOUNT]': f"₹{total_amount:,.0f}" if total_amount else "Unknown",
            '[CURRENCY]': txn_summary.get('currency', 'INR'),
            '[ALERT_TYPE]': alert_data.get('alert_type', 'Unknown'),
            '[ALERT_DATE]': alert_data.get('alert_date', 'Unknown'),
            '[AI_GENERATED_NARRATIVE]': result['narrative'],
            '[AI_GENERATED_INDICATORS]': '\n'.join(result['indicators']),
            '[TYPOLOGY_NAME]': alert_data.get('typology_match', 'Unknown'),
            '[TYPOLOGY_ANALYSIS]': result['typology'],
            '[REGULATORY_CITATIONS]': '\n'.join(result['regulatory_refs']),
            '[LEGAL_REFERENCE]': 'PMLA Section 12',
            '[COMPLIANCE_ANALYST_NAME]': analyst_name,
            '[REVIEW_DATE]': 'Pending',
            '[APPROVAL_STATUS]': 'Draft - Pending Approval',
            '[APPROVAL_DATE]': 'Pending',
            '[AUDIT_TRAIL_ID]': result['audit_trail']['alert_id'],
            '[TIMESTAMP]': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '[DOCUMENT_HASH]': 'SHA256:' + 'x' * 16 + '...'
        }
        
        for placeholder, value in replacements.items():
            sar_report = sar_report.replace(placeholder, str(value))
        
        print("✓ Full SAR report generated\n")
        
        return sar_report, result['audit_trail']


# Test function
if __name__ == "__main__":
    print("="*80)
    print("SAR GENERATOR - TEST MODE")
    print("="*80)
    
    # Load sample alert
    try:
        with open('data/sample_alerts.json', 'r') as f:
            alerts = json.load(f)
        print(f"\n✓ Loaded {len(alerts)} sample alerts")
    except FileNotFoundError:
        print("\n✗ Error: sample_alerts.json not found in data/ folder")
        print("Make sure you've moved the file: mv sample_alerts.json data/")
        exit(1)
    
    # Generate SAR for first alert
    print("\n" + "="*80)
    print("GENERATING SAR FOR FIRST ALERT")
    print("="*80)
    
    try:
        generator = SARGenerator()
        sar, audit = generator.generate_full_sar(alerts[0])
        
        print("\n" + "="*80)
        print("GENERATED SAR:")
        print("="*80)
        print(sar[:1000] + "...[truncated]")
        
        print("\n" + "="*80)
        print("AUDIT TRAIL:")
        print("="*80)
        print(json.dumps(audit, indent=2)[:500] + "...[truncated]")
        
        print("\n✅ TEST COMPLETE - SAR Generator is working!")
        
    except Exception as e:
        print(f"\n✗ Error during generation: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure Ollama is running: ollama serve")
        print("2. Check model is downloaded: ollama list")
        print("3. Verify data files are in correct locations")
